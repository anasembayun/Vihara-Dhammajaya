<?php
session_start();
$_SESSION['pagename']="Add New Supplier";
$_SESSION['suppliers']=array("PT Satu","PT Dua","PT Tiga","PT Empat","PT Lima");
?>