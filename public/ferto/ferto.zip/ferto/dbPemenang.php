<?php
require "session.php";
include_once "head.html";
$_SESSION['pagename']="";
?>

<head>
    <style>
    </style>
</head>

<!DOCTYPE html>
<html>
    

<body>
    <div class="wrapper">
        <?php include_once "sidebar.html";?>
            
        <div class="container">
            <nav>
                <div class="row">
                    <div class="col-sm">
                        <button type="button" id="sidebarcollapse" class="btn btn-info">
                            <i class="fas fa-align-left"></i>
                            <span>Menu</span>
                        </button>
                    </div>
                    <div class="col-sm">
                        <h2>    
                            <?php echo $_SESSION['pagename'];?>
                        </h2>
                    </div>
                </div>
            </nav>

                <div class="row">
                    <div class="col-sm-12">
                        <div class="mt-3">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="d-flex justify-content-between">
                                        <div class="container">
                                            <div class="row d-flex align-items-center">
                                                <div class="col-sm" style="text-align:left;">
                                                    <h4 style="text-align:left;">Database Pemenang</h4>
                                                </div>
                                                <div class="col-sm">
                                                    <button type="button" class="btn btn-success">
                                                        <i class="fa fa-file-excel-o"></i>
                                                        <span>Import</span>
                                                    </button>
                                                    <button type="button" class="btn btn-primary">
                                                        <i class="fa fa-file-excel-o"></i>
                                                        <span>Export</span>
                                                    </button>
                                                    <button type='button' class='btn btn-primary'><i class='fa fa-print'></i> Cetak</button>
                                                </div>
                                                <div class="col-sm text-right">
                                                    <button type="button" class="btn btn-primary" onclick="location.href='addDbPemenang.php'">
                                                        <span>+ Tambah</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div><hr>

                                    <div class="row">
                                        <div class="form-group col-sm-6 ">
                                            <span class="glyphicon glyphicon-name"></span>
                                            <input type="text"
                                                onkeyup="_sorting(), _filter()" name="myySearch" id="mySearch"
                                                placeholder="Search with Filter or Sorting" class="form-control search-emp">
                                        </div>
                                        <div class="form-group col-sm-3 ">
                                            <select class="form-control" id="myFilter" onkeyup="_filter()" style="width: 100%; height: 100%;">
                                                <option value="filterby">Filter by</option>
                                                <option value="id">id</option>
                                                <option value="namapemenang">Nama Pemenang</option>
                                                <option value="periode">Periode</option>
                                                <option value="bulantahun">Bulan-Tahun</option>
                                                <option value="hadiah">Hadiah</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-sm-3 ">
                                            <select class="form-control" id="mySort" onkeyup="_sorting()" style="width: 100%; height: 100%;">
                                                <option value="sortingby">Sorting by</option>
                                                <option value="ascending">ascending</option>
                                                <option value="descending">descending</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group row justify-content-center">
                                        <button class="btn col-sm-3" style="background-color:rgba(52, 25, 80, 1); color:white" id="submit" onkeyup="_sorting(), _filter()" name="submit">
                                            Submit</button> &nbsp;&nbsp;&nbsp;
                                        <button class="btn col-sm-3" style="background-color:rgba(52, 25, 80, 1); color:white" id="refresh" onClick="refreshPage()" name="refresh">
                                            Refresh</button>

                                        

                                    </div>
                                    <div class="row d-flex justify-content-center align-items-center">  
                                        <div class="col-sm-9 grid-margin ">
                                            <div class="iq-card">
                                                    
                                                    <div class="iq-card-body d-flex justify-content-center align-items-center">
                                                        <div class="table-responsive-xl" style="overflow: scroll; ">  
                                                            <table class="table table-hover table-striped table-light display sortable table-responsive text-nowrap" cellspacing="0"  id="myTable" >
                                                                <thead>
                                                                    <br>
                                                                    <tr id="_judul" onkeyup="_filter()" id="myFilter">
                                                                        <th >ID</th>
                                                                        <th >Nama Pemenang</th>
                                                                        <th >Periode</th>
                                                                        <th >Bulan-Tahun</th>
                                                                        <th >Hadiah</th>
                                                                        <th></th>
                                                                    </tr>
                                                                </thead>

                                                                <tbody>
                                                                    <tr>
                                                                        <td class="align-middle">H1</td>
                                                                        <td>
                                                                        <img src=images/user/11.png alt=profile-img class=avatar-50 img-fluid/>
                                                                            Hendro
                                                                        </td>
                                                                        <td class="align-middle">1</td>
                                                                        <td class="align-middle">Januari-2010</td>
                                                                        <td class="align-middle">Televisi 14 inch</td>
                                                                        <td class="align-middle">
                                                                            <div class='btn-group'>
                                                                                <button type='button' class='btn btn-edit' onclick="location.href='editDbPemenang.php'"  style='color: #FDBE33;'>
                                                                                    <i class='fas fa-edit'></i>&nbspEdit</button>
                                                                                <button type='button' class='btn btn-remove' data-toggle='modal'
                                                                                    data-target='#mmMyModal' style='color: grey;'>
                                                                                    <i class='fas fa-trash'></i>&nbspRemove</button>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="align-middle">H2</td>
                                                                        <td>
                                                                        <img src=images/user/11.png alt=profile-img class=avatar-50 img-fluid/>
                                                                            Setiawan
                                                                        </td>
                                                                        <td class="align-middle">1</td>
                                                                        <td class="align-middle">Januari-2010</td>
                                                                        <td class="align-middle">Iphone 13 Pro Max</td>
                                                                        <td class="align-middle">
                                                                            <div class='btn-group'>
                                                                                <button type='button' class='btn btn-edit' onclick="location.href='editDbPemenang.php'"  style='color: #FDBE33;'>
                                                                                    <i class='fas fa-edit'></i>&nbspEdit</button>
                                                                                <button type='button' class='btn btn-remove' data-toggle='modal'
                                                                                    data-target='#mmMyModal' style='color: grey;'>
                                                                                    <i class='fas fa-trash'></i>&nbspRemove</button>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="align-middle"> H3</td>
                                                                        <td>
                                                                        <img src=images/user/11.png alt=profile-img class=avatar-50 img-fluid/>
                                                                            Hendro
                                                                        </td>
                                                                        <td class="align-middle">2</td>
                                                                        <td class="align-middle">Januari-2011</td>
                                                                        <td class="align-middle">Camera Canon</td>
                                                                        <td class="align-middle">
                                                                            <div class='btn-group'>
                                                                                <button type='button' class='btn btn-edit' onclick="location.href='editDbPemenang.php'"  style='color: #FDBE33;'>
                                                                                    <i class='fas fa-edit'></i>&nbspEdit</button>
                                                                                <button type='button' class='btn btn-remove' data-toggle='modal'
                                                                                    data-target='#mmMyModal' style='color: grey;'>
                                                                                    <i class='fas fa-trash'></i>&nbspRemove</button>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="align-middle">H4</td>
                                                                        <td>
                                                                        <img src=images/user/11.png alt=profile-img class=avatar-50 img-fluid/>
                                                                            Pakuti
                                                                        </td>
                                                                        <td class="align-middle">3</td>
                                                                        <td class="align-middle">Januari-2012</td>
                                                                        <td class="align-middle">Oppo F1S</td>
                                                                        <td class="align-middle">
                                                                            <div class='btn-group'>
                                                                                <button type='button' class='btn btn-edit' onclick="location.href='editDbPemenang.php'"  style='color: #FDBE33;'>
                                                                                    <i class='fas fa-edit'></i>&nbspEdit</button>
                                                                                <button type='button' class='btn btn-remove' data-toggle='modal'
                                                                                    data-target='#mmMyModal' style='color: grey;'>
                                                                                    <i class='fas fa-trash'></i>&nbspRemove</button>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="align-middle">H4</td>
                                                                        <td>
                                                                        <img src=images/user/11.png alt=profile-img class=avatar-50 img-fluid/>
                                                                            Maried
                                                                        </td>
                                                                        <td class="align-middle">3</td>
                                                                        <td class="align-middle">Januari-2012</td>
                                                                        <td class="align-middle">Rumah 1 hektar</td>
                                                                        <td class="align-middle">
                                                                            <div class='btn-group'>
                                                                                <button type='button' class='btn btn-edit' onclick="location.href='editDbPemenang.php'"  style='color: #FDBE33;'>
                                                                                    <i class='fas fa-edit'></i>&nbspEdit</button>
                                                                                <button type='button' class='btn btn-remove' data-toggle='modal'
                                                                                    data-target='#mmMyModal' style='color: grey;'>
                                                                                    <i class='fas fa-trash'></i>&nbspRemove</button>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>

                                                        <div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    
                                    <!-- Modal Remove Account -->
                                    <div class="modal fade" id="mmMyModal" role="dialog" style="border-radius:45px">
                                        <div class="modal-dialog">
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header" style="background:rgba(52, 25, 80, 1); color:white;">
                                                    <p id="employeeidname" style="font-weight: bold;">Hendro</p>
                                                    <button type="button" class="close" data-dismiss="modal" style="color:white;">×</button>
                                                </div>

                                                <div class="modal-body">
                                                    <button id="btnModalBiodata" onclick="msuccess('remove')" style="text-align:left">
                                                        <a style="color: rgba(3, 15, 39, 1);">
                                                            <i class='fas fa-edit'></i>&nbspRemove Database Pemenang</a></button>
                                                    <hr>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
        </div>
    </div>
    
    <script>
        // $('#myTable').DataTable();

        $(document).ready(function () {
        $('#myTable').DataTable({
            "order": [[ 3, "desc" ]]
        });
            $('.dataTables_length').addClass('bs-select');
        });
        $(document).ready(
            function(){
                $('#sidebarcollapse').on('click',function(){
                    $('#sidebar').toggleClass('active');
                });
            }
        )
        $(document).ready(
            function(){
                var handlerid=5;
                $.ajax({
                    url:"handler.php",
                    type:"POST",
                    data:{handlerid:handlerid},
                    success: function(response){
                        $('#tablebody').html(response);
                    },
                    error:function(xhr,textStatus,errorThrown){
                        var str="ERROR : SERVER error<br>"+xhr+
                        "<br>" + textStatus + "<br>" + errorThrown;
                        alert(str);
                    }
                });
            }
        )
        function msuccess(str){
            $('#mmMyModal').modal('hide');
            $('#scmode').text(str);
            var handlerid=4;
            $.ajax({
                    url:"handler.php",
                    type:"POST",
                    data:{handlerid:handlerid},
                    success: function(response){
                        $('#ModalSuccess').modal();
                    },
                    error:function(xhr,textStatus,errorThrown){
                        var str="ERROR : SERVER error<br>"+xhr+
                        "<br>" + textStatus + "<br>" + errorThrown;
                        alert(str);
                    }
                });
        }

        function refreshPage() {
            document.getElementById("mySearch").value = "";
            document.getElementById("myFilter").innerHTML = "filterby";
            document.getElementById("mySort").innerHTML = "sortingby";

            // }
            window.location.reload();
        }

        $("button").click(function () {

            var _mySort = document.getElementById("mySort").value;
            var _myFilter = document.getElementById("myFilter").value;
            if (_mySort != "sortingby" && _myFilter != "filterby") {
                alert("Mohon Maaf, Harap Mengisi Salah Satu dari Sorting atau Filter.")
            }
            else if (_mySort != "sortingby") {
                // alert("sort");
                _sorting();
            }

            else if (_myFilter != "filterby") {
                // alert("filter");
                _filter();
            }
            function _sorting() {
                var table, rows, switching, i, x, y, shouldSwitch, input, index, whatSort, indexSort;
                input = document.getElementById("mySearch").value;
                if (input == "id" || input == "ID") {
                    index = 0;
                }
                else if (input == "namapemenang" || input == "Namapemenang") {
                    index = 1;
                }
                else if (input == "periode" || input == "Periode") {
                    index = 2;
                }
                else if (input == "bulntahun" || input == "Bulantahun") {
                    index = 3;
                }
                else if (input == "hadiah" || input == "Hadiah") {
                    index = 4;
                }
                

                whatSort = document.getElementById("mySort").value;

                if (whatSort == "ascending" || whatSort == "Ascending") {
                    indexSort = 1;
                }
                else if (whatSort == "descending" || whatSort == "Descending") {
                    indexSort = 2;
                }
                table = document.getElementById("myTable");
                switching = true;
                if (indexSort == 1) {
                    while (switching) {
                        switching = false;
                        rows = table.rows;
                        for (i = 1; i < (rows.length - 1); i++) {
                            shouldSwitch = false;
                            x = rows[i].getElementsByTagName("TD")[index];
                            y = rows[i + 1].getElementsByTagName("TD")[index];
                            if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                                shouldSwitch = true;
                                break;
                            }
                        }
                        if (shouldSwitch) {
                            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                            switching = true;
                        }
                    }
                }
                else if (indexSort == 2) {
                    while (switching) {
                        switching = false;
                        rows = table.rows;
                        for (i = 1; i < (rows.length - 1); i++) {
                            shouldSwitch = false;
                            x = rows[i].getElementsByTagName("TD")[index];
                            y = rows[i + 1].getElementsByTagName("TD")[index];
                            if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                                shouldSwitch = true;
                                break;
                            }

                        }
                        if (shouldSwitch) {
                            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                            switching = true;
                        }
                    }
                }
            }




            function _filter() {
                var input, filter, table, tr, td, i, txtValue, index;
                input = document.getElementById("mySearch");
                filter = input.value.toUpperCase();
                table = document.getElementById("myTable");
                tr = table.getElementsByTagName("tr");
                filt = document.getElementById("myFilter").value;
                $('myFilter').click(function () {
                    filt = document.getElementById("myFilter").value;
                });

                if (filt == "id" || filt == "ID") {
                    index = 0;
                }
                if (filt == "namapemenang" || filt == "Namapemenang") {
                    index = 1;
                }
                if (filt == "periode" || filt == "Periode") {
                    index = 2;
                }
                if (filt == "bulantahun" || filt == "Bulantahun") {
                    index = 3;
                }
                if (filt == "hadiah" || filt == "Hadiah") {
                    index = 4;
                }
                

                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[index];
                    if (td) {
                        txtValue = td.textContent || td.innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        } else {
                            tr[i].style.display = "none";
                        }
                    }
                }
            }

        })

    </script>
</body>

</html>