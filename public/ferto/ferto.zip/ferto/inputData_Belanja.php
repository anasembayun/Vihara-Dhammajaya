<?php
require "session.php";
include_once "head.html";
$_SESSION['pagename']="";
?>

<!DOCTYPE html>
<html lang="en">

<body>

    <div class="wrapper">
        <?php include_once "sidebar.html"?>
        <div class="container">
            <nav>
                <div class="row">
                    <div class="col-sm">
                        <button type="button" id="sidebarcollapse" class="btn btn-info">
                            <i class="fas fa-align-left"></i>
                            <span>Menu</span>
                        </button>
                    </div>
                    <div class="col-sm">
                        <h2>
                            <?php echo $_SESSION['pagename'];?>
                        </h2>
                    </div>
                </div>
            </nav>
            <div class="container justify text-left">
                <div class="container">
                    <!-- <div id="rcorners2"> -->
                        <!-- <form action="#"> -->
                            <div class="form-group row">
                                <label for="Periode Undian" class="col-sm-2">Periode Undian</label>

                                <div class="col-10">
                                    <select class="form-control" id="province" name="province">
                                        <option value="department">Pilih Periode</option>
                                        <option value="periode1">Periode 1</option>
                                        <option value="periode2">Periode 2</option>
                                        <option value="periode3">Periode 3</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Tanggal Belanja" class="col-sm-2 col-form-label">Tanggal Belanja</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" id="tglbelanja">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Toko" class="col-sm-2 col-form-label">Toko</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="toko">
                                </div>
                            </div>
                            <!-- <div class="form-group row">
                                <label for="Toko" class="col-sm-2 col-form-label">Toko</label>
                                <div class="col-sm-10">
                                    <select class="selectpicker" data-live-search="true" data-width="100%">
                                        <option value="" disabled selected hidden>Pilih Nama Toko</option>
                                        <option>Toko 1</option>
                                        <option>Toko 2</option>
                                        <option>Toko 3</option>
                                    </select>
                                </div>
                            </div> -->
                            <div class="form-group row">
                                <label for="No HP" class="col-sm-2 col-form-label">Nomor HP</label>
                                <div class="col-sm-10">
                                    <input  class="form-control" id="nohp">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Nama" class="col-sm-2 col-form-label">Nama Lengkap</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="nama">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Alamat" class="col-sm-2 col-form-label">Alamat Domisili</label>
                                <div class="col-sm-10">
                                    <textarea class="form-control" id="alamat" rows="3"></textarea>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Kelurahan" class="col-sm-2 col-form-label">Kelurahan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="kelurahan">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Kecamatan" class="col-sm-2 col-form-label">Kecamatan</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="kecamatan">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="kota/kabupaten" class="col-sm-2 col-form-label ">Kota / Kabupaten</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="kota/kab">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Total Nilai Belanja" class="col-sm-2 col-form-label ">Total Nilai
                                    Belanja</label>
                                <div class="col-sm-10">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <label class="input-group-text" for="Input Total">IDR</label>
                                        </div>
                                        <input type="text" class="form-control" id="total">
                                        <div class="kupon-inline">
                                            <small>
                                                &nbspAnda akan mendapatkan
                                                <span id="">50</span>
                                                Kupon
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <!-- </form> -->
                    <!-- </div> -->
                </div>
                <div class="form-group text-right">
                    <input type="submit" onclick="" class="btn btn-primary submit" value="Submit">
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(
            function () {
                $('#sidebarcollapse').on('click', function () {
                    $('#sidebar').toggleClass('active');
                });
            }
        )
    </script>
</body>

</html>